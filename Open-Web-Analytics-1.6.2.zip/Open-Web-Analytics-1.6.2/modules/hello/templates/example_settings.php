<h2><?php echo $headline; ?></h2>

Hello world. This is how you create a settings page.