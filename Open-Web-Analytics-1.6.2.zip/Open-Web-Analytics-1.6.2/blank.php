<?php 
// silence is golden.
?>